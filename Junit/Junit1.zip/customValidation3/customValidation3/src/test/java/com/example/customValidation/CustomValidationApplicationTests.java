package com.example.customValidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomValidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
