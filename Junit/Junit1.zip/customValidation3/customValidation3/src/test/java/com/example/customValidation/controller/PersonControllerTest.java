package com.example.customValidation.controller;

import com.example.customValidation.service.PersonService;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class PersonControllerTest {

    @InjectMocks
    private  PersonController personController;

    @Mock
    private PersonService personService;
}
