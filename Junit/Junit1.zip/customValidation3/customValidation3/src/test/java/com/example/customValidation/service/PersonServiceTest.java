package com.example.customValidation.service;

import com.example.customValidation.entity.AddressEntity;
import com.example.customValidation.entity.PersonEntity;
import com.example.customValidation.mapper.AddressMapper;
import com.example.customValidation.mapper.PersonMapper;
import com.example.customValidation.model.Address;

import com.example.customValidation.model.PatchPerson;
import com.example.customValidation.model.Person;
import com.example.customValidation.model.PersonResponse;
import com.example.customValidation.repository.AddressRepository;
import com.example.customValidation.repository.PersonRepository;

import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Optional;


@ExtendWith(MockitoExtension.class)
@Log4j2

public class PersonServiceTest extends Assertions {

    private static final Long id = 1L;

    @InjectMocks
    public PersonService personService;
    @Mock
    private PersonRepository personRepository;
    @Mock
    private PersonMapper personMapper;
    @Mock
    private AddressMapper addressMapper;
    @Mock
    private AddressRepository addressRepository;

    @BeforeEach
    void setup()
    {
        PersonMapper personMapper = Mappers.getMapper(PersonMapper.class);
        ReflectionTestUtils.setField(personService, "personMapper", personMapper);
    }


    @Test
    void testCreatePerson() throws Exception
    {
        //Setting Model Body
        Person person=new Person();
        person.setFirstName("Adi");
        person.setLastName("Mhatre");

        Address address=new Address();
        address.setAddressOne("iuh");
        address.setAddressTwo("gyu");
        address.setCity("fg");
        address.setState("tf");
        address.setZipCode("987654");

        person.setAddressEntity(address);

        PersonResponse personResponse=new PersonResponse();
        personResponse.setId(1L);

        //Setting Entity Body
        PersonEntity personEntity=new PersonEntity();
        personEntity.setId(personResponse.getId());
        personEntity.setFirstName(person.getFirstName());
        personEntity.setLastName(person.getLastName());

        AddressEntity addressEntity=new AddressEntity();
        addressEntity.setAddressOne(address.getAddressOne());
        addressEntity.setAddressTwo(address.getAddressTwo());
        addressEntity.setCity(address.getCity());
        addressEntity.setState(address.getState());
        addressEntity.setZipCode(address.getZipCode());
        addressEntity.setId(personResponse.getId());

        personEntity.setAddressEntity(addressEntity);

     /* Mockito.when(addressMapper.addressToAddressEntity(person.getAddress())).thenReturn(addressEntity);
       Mockito.when(personMapper.personToEntity(person)).thenReturn(personEntity);*/

        // Mocking Save method
        Mockito.when(personRepository.save(Mockito.any(PersonEntity.class))).thenReturn(personEntity);

        //Testing Actual Method and Mapper
        PersonResponse personResponse1 = personService.createPerson(person);
        personResponse1.setFirstName(personEntity.getFirstName());

        //Comparing The OutPut
        assertEquals("Adi",personResponse1.getFirstName());
        assertNotNull(personResponse1.getFirstName());
    }

    @Test
    void testGetPerson() throws Exception
    {
        PersonEntity personEntity=new PersonEntity();
        AddressEntity addressEntity=new AddressEntity();

        personEntity.setId(101L);
        personEntity.setFirstName("Aditya");
        personEntity.setLastName("Mhatre");

        addressEntity.setAddressOne("gyusd");
        addressEntity.setAddressTwo("ghd");
        addressEntity.setCity("sdjgz");
        addressEntity.setState("TAsd");
        addressEntity.setZipCode("345678");

        personEntity.setAddressEntity(addressEntity);

        Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(personEntity));

        Person person= personService.getPerson(101L);
        person.setFirstName(personEntity.getFirstName());
        person.setLastName(personEntity.getLastName());

        Address address=new Address();
        address.setAddressOne(addressEntity.getAddressOne());
        address.setAddressTwo(addressEntity.getAddressTwo());
        address.setCity(addressEntity.getCity());
        address.setState(addressEntity.getState());
        address.setZipCode(addressEntity.getZipCode());

        person.setAddressEntity(address);

        assertEquals("Aditya",person.getFirstName());
        assertEquals("Mhatre",person.getLastName());
        assertNotNull(person.getAddressEntity());
    }


    @Test
    void testDeletePerson() throws Exception
    {
    Mockito.doNothing().when(personRepository).deleteById(Mockito.anyLong());
    personService.deletePerson(10L);
    Mockito.verify(personRepository).deleteById(Mockito.anyLong());
    }


    @Test
    void testUpdatePerson()throws Exception
    {
        Person person=new Person();
        person.setFirstName("Adi");
        person.setLastName("Mhatre");

        Address address=new Address();
        address.setAddressOne("iuh");
        address.setAddressTwo("gyu");
        address.setCity("fg");
        address.setState("tf");
        address.setZipCode("987654");

        person.setAddressEntity(address);

        PersonEntity personEntity=new PersonEntity();
        AddressEntity addressEntity=new AddressEntity();

        personEntity.setId(101L);
        personEntity.setFirstName("Aditya");
        personEntity.setLastName("Mhatre");

        addressEntity.setAddressOne("gyusd");
        addressEntity.setAddressTwo("ghd");
        addressEntity.setCity("sdjgz");
        addressEntity.setState("TAsd");
        addressEntity.setZipCode("345678");

        personEntity.setAddressEntity(addressEntity);

        Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(personEntity));

        personService.updatePerson(101L,person);

    }


    @Test
    void testPatchPerson() throws Exception
    {
        PatchPerson person=new PatchPerson();
        person.setFirstName("Adi");
        person.setLastName("Mhatre");

        PersonEntity personEntity=new PersonEntity();
        AddressEntity addressEntity=new AddressEntity();

        personEntity.setId(101L);
        personEntity.setFirstName("Aditya");
        personEntity.setLastName("Mhatre");

        addressEntity.setAddressOne("gyusd");
        addressEntity.setAddressTwo("ghd");
        addressEntity.setCity("sdjgz");
        addressEntity.setState("TAsd");
        addressEntity.setZipCode("345678");
        personEntity.setAddressEntity(addressEntity);

        Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(personEntity));
        personService.patchPerson(101L, person);


        assertEquals("Adi",personEntity.getFirstName());
        assertEquals("Mhatre",personEntity.getLastName());
        assertNotNull(personEntity);



    }

    @Test
    void testPatchPersonRequestParam()throws Exception
    {
        PersonEntity personEntity=new PersonEntity();
        AddressEntity addressEntity=new AddressEntity();

        personEntity.setId(101L);
        personEntity.setFirstName("Aditya");
        personEntity.setLastName("Mhatre");

        addressEntity.setAddressOne("gyusd");
        addressEntity.setAddressTwo("ghd");
        addressEntity.setCity("sdjgz");
        addressEntity.setState("TAsd");
        addressEntity.setZipCode("345678");
        personEntity.setAddressEntity(addressEntity);

        Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(personEntity));

        personService.patchPersonRequestParam(101L,"Shiv");

        assertEquals("Shiv",personEntity.getFirstName());

    }
}