package com.example.customValidation.service;

import com.example.customValidation.entity.AddressEntity;
import com.example.customValidation.entity.PersonEntity;
import com.example.customValidation.mapper.AddressMapper;
import com.example.customValidation.mapper.PersonMapper;
import com.example.customValidation.model.Address;

import com.example.customValidation.model.PatchPerson;
import com.example.customValidation.model.Person;
import com.example.customValidation.model.PersonResponse;
import com.example.customValidation.repository.AddressRepository;
import com.example.customValidation.repository.PersonRepository;

import com.example.customValidation.testUtils.MockUtils;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Optional;


@ExtendWith(MockitoExtension.class)
@Log4j2

public class PersonServiceTest extends Assertions {

    private static final Long id = 1L;

    @InjectMocks
    public PersonService personService;
    @Mock
    private PersonRepository personRepository;
    @Mock
    private PersonMapper personMapper;
    @Mock
    private AddressMapper addressMapper;


    @BeforeEach
    void setup()
    {
        PersonMapper personMapper = Mappers.getMapper(PersonMapper.class);
        ReflectionTestUtils.setField(personService, "personMapper", personMapper);
    }


    @Test
    void testCreatePerson() throws Exception
    {
        Person person= MockUtils.modelSetUp();


        PersonResponse personResponse=new PersonResponse();
        personResponse.setId(1L);



        PersonEntity personEntity=new PersonEntity();
        personEntity.setId(personResponse.getId());
        personEntity.setFirstName(person.getFirstName());
        personEntity.setLastName(person.getLastName());

        AddressEntity addressEntity=new AddressEntity();
        addressEntity.setAddressOne(person.getAddressEntity().getAddressOne());
        addressEntity.setAddressTwo(person.getAddressEntity().getAddressTwo());
        addressEntity.setCity(person.getAddressEntity().getCity());
        addressEntity.setState(person.getAddressEntity().getState());
        addressEntity.setZipCode(person.getAddressEntity().getZipCode());
        addressEntity.setId(personResponse.getId());

        personEntity.setAddressEntity(addressEntity);

        Mockito.when(personRepository.save(Mockito.any(PersonEntity.class))).thenReturn(personEntity);
        PersonResponse personResponse1 = personService.createPerson(person);

        personResponse1.setFirstName(personEntity.getFirstName());

        assertEquals("Adi",personResponse1.getFirstName());
        assertNotNull(personResponse1.getFirstName());
    }

    @Test
    void testGetPerson() throws Exception
    {
      PersonEntity personEntity= MockUtils.entitySetUp();

        Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(personEntity));

        Person person= personService.getPerson(101L);

        assertEquals("Aditya",person.getFirstName());
        assertEquals("Mhatre",person.getLastName());

    }


    @Test
    void testDeletePerson() throws Exception
    {
    Mockito.doNothing().when(personRepository).deleteById(Mockito.anyLong());
    personService.deletePerson(10L);
    Mockito.verify(personRepository).deleteById(Mockito.anyLong());
    }


    @Test
    void testUpdatePerson()throws Exception
    {
        Person person= MockUtils.modelSetUp();
        PersonEntity personEntity= MockUtils.entitySetUp();

        Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(personEntity));

        personService.updatePerson(101L,person);

    }


    @Test
    void testPatchPerson() throws Exception
    {
        PatchPerson patchPerson=MockUtils.patchSetUp();

        PersonEntity personEntity=MockUtils.entitySetUp();

        Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(personEntity));
        personService.patchPerson(101L, patchPerson);

        assertEquals("Adi",personEntity.getFirstName());
        assertEquals("Mhatre",personEntity.getLastName());
        assertNotNull(personEntity);



    }

    @Test
    void testPatchPersonRequestParam()throws Exception
    {
        PersonEntity personEntity=MockUtils.entitySetUp();

        Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(personEntity));

        personService.patchPersonRequestParam(101L,"Shiv");

        assertEquals("Shiv",personEntity.getFirstName());

    }
}