package com.example.customValidation.service;

import com.example.customValidation.entity.AddressEntity;
import com.example.customValidation.entity.PersonEntity;
import com.example.customValidation.expectionHandler.PersonStatusException;
import com.example.customValidation.mapper.AddressMapper;
import com.example.customValidation.mapper.PersonMapper;
import com.example.customValidation.model.Address;
import com.example.customValidation.model.PatchPerson;
import com.example.customValidation.model.Person;
import com.example.customValidation.model.PersonResponse;
import com.example.customValidation.repository.AddressRepository;
import com.example.customValidation.repository.PersonRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
@Log4j2
@RequiredArgsConstructor
public class PersonService {


    private final PersonRepository personRepository;

    private final PersonMapper personMapper;

    private final AddressMapper addressMapper;




    public PersonResponse createPerson(Person person) {
        PersonEntity personEntity = personMapper.personToEntity(person);
        personRepository.save(personEntity);

        PersonResponse personResponse = new PersonResponse();
        personResponse.setId(personEntity.getId());
        log.info("details of {} {}", person.getFirstName(), person.getLastName() + " Inserted successfully");
        return personResponse;
    }

    public Person getPerson(Long id) {

        return personRepository.findById(id).map(this::getPerson).orElseThrow(() -> new PersonStatusException( "Person can not be found with id:"+id));
    }

    private Person getPerson(PersonEntity personEntity) {
        AddressEntity addressEntity = personEntity.getAddressEntity();
        Person person = personMapper.entityToPerson(personEntity);
        Address address = addressMapper.addressEntityToAddress(addressEntity);
        person.setAddressEntity(address);
        return person;
    }

    public void deletePerson(Long id) {
        try{
            personRepository.deleteById(id);
        }
        catch (Exception ex){
           throw new PersonStatusException("Person ID not found");
        }


    }
  


    public void updatePerson(Long id, Person person) {
        Optional<PersonEntity> personEntityOptional = personRepository.findById(id);
        if (personEntityOptional.isPresent()) {
            PersonEntity personEntity = personEntityOptional.get();
            AddressEntity addressEntity = personEntity.getAddressEntity();
            personEntity.setFirstName(person.getFirstName());
            personEntity.setLastName(person.getLastName());

            addressEntity.setAddressOne(person.getAddressEntity().getAddressOne());
            addressEntity.setAddressTwo(person.getAddressEntity().getAddressTwo());
            addressEntity.setCity(person.getAddressEntity().getCity());
            addressEntity.setState(person.getAddressEntity().getState());
            addressEntity.setZipCode(person.getAddressEntity().getZipCode());

            personEntity.setAddressEntity(addressEntity);
            personRepository.save(personEntityOptional.get());
            log.info("Person id {}", id + " updated successfully");
        } else {
            log.info("Id Not Found");
        }
    }

    public PatchPerson patchPerson(Long id, PatchPerson patchPerson)
    {
        Optional<PersonEntity>personEntityOptional=personRepository.findById(id);
        PersonEntity personEntity=personEntityOptional.get();
        if (personEntityOptional.isPresent()){
            personEntity.setFirstName(patchPerson.getFirstName());
            personEntity.setLastName(patchPerson.getLastName());
        }

        personRepository.save(personEntity);
        log.info("Patching.....");
        return patchPerson;

    }

    public void patchPersonRequestParam(Long id, String firstName) {
        PersonEntity personEntity=personRepository.findById(id).get();
        personEntity.setFirstName(firstName);
        personRepository.save(personEntity);
    }
}
