package com.example.customValidation.service;

import com.example.customValidation.entity.PersonEntity;
import com.example.customValidation.expectionHandler.PersonStatusException;
import com.example.customValidation.mapper.AddressMapper;
import com.example.customValidation.mapper.PersonMapper;

import com.example.customValidation.model.PatchPerson;
import com.example.customValidation.model.Person;
import com.example.customValidation.model.PersonResponse;
import com.example.customValidation.repository.PersonRepository;

import com.example.customValidation.testUtils.MockUtils;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Optional;


@ExtendWith(MockitoExtension.class)
@Log4j2

public class PersonServiceTest extends Assertions
    {
        @InjectMocks
        public PersonService personService;
        @Mock
        private PersonRepository personRepository;
        @Mock
        private PersonMapper personMapper;
        @Mock
        private AddressMapper addressMapper;


        @BeforeEach
        void setup()
        {
            PersonMapper personMapper = Mappers.getMapper(PersonMapper.class);
            ReflectionTestUtils.setField(personService, "personMapper", personMapper);
        }


        @Test
        void testCreatePerson()
        {
            Person person= MockUtils.modelSetUp();
            PersonEntity personEntity= MockUtils.entitySetUp();

            Mockito.when(personRepository.save(Mockito.any(PersonEntity.class))).thenReturn(personEntity);
            PersonResponse personResponse1 = personService.createPerson(person);

            assertEquals("Adi",personResponse1.getFirstName());
            assertNotNull(personResponse1.getFirstName());
        }

        @Test
        void testCreatePersonWhenCreatePersonExceptionOccurs()
        {
            Mockito.when(personRepository.save(Mockito.any(PersonEntity.class))).thenThrow(PersonStatusException.class);
            assertThrows(PersonStatusException.class ,() -> personService.createPerson(Mockito.any(Person.class)));
            Mockito.verify(personRepository).save(Mockito.any());
        }

        @Test
        void testGetPerson()
        {
          PersonEntity personEntity= MockUtils.entitySetUp();
          Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(personEntity));
          Person person= personService.getPerson(101L);

          assertEquals("Aditya",person.getFirstName());
          assertEquals("Mhatre",person.getLastName());
        }

        @Test
        void testGetPersonWhenIdNotFoundExceptionOccurs()
        {
            Mockito.when(personRepository.findById(Mockito.anyLong())).thenThrow(PersonStatusException.class);
            assertThrows(PersonStatusException.class, ()-> personService.getPerson(Mockito.anyLong()));
            Mockito.verify(personRepository).findById(Mockito.anyLong());
        }



        @Test
        void testDeletePersonWhenIdNotFound()
        {
            Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
            assertThrows(PersonStatusException.class, ()-> personService.deletePerson(19L));
            Mockito.verify(personRepository).findById(Mockito.anyLong());
        }


        @Test
        void testUpdatePerson()
        {
            Person person= MockUtils.modelSetUp();
            PersonEntity personEntity= MockUtils.entitySetUp();

            Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(personEntity));
            personService.updatePerson(101L,person);

        }

        @Test
        void testUpdatePersonWhenIdNotFoundExceptionOccurs()
        {
            Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
            assertThrows(PersonStatusException.class, ()-> personService.updatePerson(19L,MockUtils.modelSetUp()));
            Mockito.verify(personRepository).findById(Mockito.anyLong());
        }


        @Test
        void testPatchPerson()
        {
            PatchPerson patchPerson=MockUtils.patchSetUp();
            PersonEntity personEntity=MockUtils.entitySetUp();
            Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(personEntity));
            personService.patchPerson(101L, patchPerson);
            assertEquals("Adi",personEntity.getFirstName());
            assertEquals("Mhatre",personEntity.getLastName());
            assertNotNull(personEntity);
        }

        @Test
        void testPatchPersonWhenIdNotFoundExceptionOccurs()
        {
            Mockito.when(personRepository.findById(Mockito.anyLong())).thenThrow(PersonStatusException.class);
            assertThrows(PersonStatusException.class, ()-> personService.getPerson(Mockito.anyLong()));
            Mockito.verify(personRepository).findById(Mockito.anyLong());
        }

        @Test
        void testPatchPersonRequestParam()
        {
            PersonEntity personEntity=MockUtils.entitySetUp();
            Mockito.when(personRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(personEntity));
            personService.patchPersonRequestParam(101L,"Shiv");
            assertEquals("Shiv",personEntity.getFirstName());
        }

    }