package com.example.globalexpectionhandler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobalexpectionhandlerApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlobalexpectionhandlerApplication.class, args);
	}

}
