package com.example.patientdetails.service;

import com.example.patientdetails.entity.PatientEntity;
import com.example.patientdetails.entity.PracticeEntity;
import com.example.patientdetails.mapper.ListMapper;
import com.example.patientdetails.mapper.PatientMapper;
import com.example.patientdetails.model.PatientRequest;
import com.example.patientdetails.model.PatientResponse;
import com.example.patientdetails.model.PracticeRequest;
import com.example.patientdetails.repository.PatientRepository;
import com.example.patientdetails.repository.PracticeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Log4j2
public class PatientService
    {
        private final PatientRepository patientRepository;
        private final PracticeRepository practiceRepository;
        private final PatientMapper patientMapper;

        private final ListMapper listMapper;


        public PatientResponse createPatientEntry(PatientRequest patientRequest)
        {
            PatientEntity patientEntity= patientMapper.patientToEntity(patientRequest);
            patientRepository.save(patientEntity);

            PatientResponse patientResponse=new PatientResponse();
            patientResponse.setId(patientEntity.getId());
            patientResponse.setFirstName(patientEntity.getFirstName());
            patientResponse.setLastName(patientRequest.getLastName());

            log.info("Creating Records....");

            return patientResponse;

        }

        public PatientRequest getById(Long id)
        {
            Optional<PatientEntity> patientEntity=patientRepository.findById(id);

            PatientRequest patientRequest=new PatientRequest();
            if(patientEntity.isPresent())
            {
                patientRequest=patientMapper.entityToPatient(patientEntity.get());
                log.info("Fetching....");
            }
            else
            {
                log.info("trd");
            }
            return patientRequest;

        }

        public PatientRequest updateByIdPatient(Long id, PatientRequest patientRequest)
        {
            Optional<PatientEntity> patientEntity= patientRepository.findById(id);

            if(patientEntity.isPresent())
            {
                List<PracticeEntity> practiceEntities = patientEntity.get().getPractices();
                log.info(practiceEntities);
                PatientEntity patientEntity1 =new PatientEntity();
                patientEntity1.setPractices(practiceEntities);

                      patientEntity1=  patientMapper.patientToEntity(patientRequest);
                patientEntity1.setId(id);

//                List<Long> practiceIds= new ArrayList<>();
//
//                for (PracticeEntity p:practiceEntities)
//                {
//                    practiceIds.add(p.getId());
//
//                }
                PracticeEntity practiceEntity=new PracticeEntity();
                log.info(practiceEntity.getId());

//                log.info(practiceIds);



//                practiceEntities.set(listMapper.practiceRequestListToPracticeentityList(patientRequest.getPractices()));
//                patientEntity1.setPractices(practiceEntities);
                patientRepository.save(patientEntity1);
            }
            else{

            }
            return patientRequest;

        }

        public PracticeRequest updateByIdPractice(Long id, PracticeRequest practiceRequest)
        {
            Optional<PracticeEntity> practiceEntity= practiceRepository.findById(id);

            if(practiceEntity.isPresent()) {
                practiceEntity.get().setPracticeName(practiceRequest.getPracticeName());
                practiceEntity.get().setCopay(practiceRequest.getCopay());
                practiceRepository.save(practiceEntity.get());
            }
            else{

            }
            return practiceRequest;
        }

        public void deleteById(Long id)
        {
            patientRepository.deleteById(id);
        }


        public List<PatientRequest> getAllRecords()
        {
            return patientMapper.entityListToPatientList(patientRepository.findAll());
        }


    }
