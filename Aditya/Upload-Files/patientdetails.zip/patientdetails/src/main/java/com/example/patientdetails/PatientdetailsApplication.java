package com.example.patientdetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientdetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientdetailsApplication.class, args);
	}

}
