package com.crossasyst.cassandra.model;

public enum Status {
    Employed,

    UnEmployed,

    SelfEmployed
}
