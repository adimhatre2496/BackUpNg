package com.example.jasyptencryption;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JasyptencryptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
