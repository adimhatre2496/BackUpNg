package com.example.restservice2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Restservice2Application {

	public static void main(String[] args) {
		SpringApplication.run(Restservice2Application.class, args);
	}

}
