package com.example.studentcsvpdf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentcsvpdfApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentcsvpdfApplication.class, args);
	}

}
