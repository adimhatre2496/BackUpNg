package com.example.studentcsvpdf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentcsvpdfApplicationTests {

	@Test
	void contextLoads() {
	}

}
