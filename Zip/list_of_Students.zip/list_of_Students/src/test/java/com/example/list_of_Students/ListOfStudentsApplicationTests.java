package com.example.list_of_Students;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListOfStudentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
