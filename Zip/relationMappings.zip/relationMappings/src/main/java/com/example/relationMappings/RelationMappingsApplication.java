package com.example.relationMappings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelationMappingsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelationMappingsApplication.class, args);
	}

}
