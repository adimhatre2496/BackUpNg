package com.example.relationMappings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelationMappingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
