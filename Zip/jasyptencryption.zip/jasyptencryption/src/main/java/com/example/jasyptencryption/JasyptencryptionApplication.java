package com.example.jasyptencryption;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JasyptencryptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(JasyptencryptionApplication.class, args);
	}

}
