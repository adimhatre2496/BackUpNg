package com.example.casssandra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CasssandraApplicationTests {

	@Test
	void contextLoads() {
	}

}
