package com.example.casssandra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CasssandraApplication {

	public static void main(String[] args) {
		SpringApplication.run(CasssandraApplication.class, args);
	}

}
