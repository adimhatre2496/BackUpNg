package com.example.OracleConnection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OracleConnectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
