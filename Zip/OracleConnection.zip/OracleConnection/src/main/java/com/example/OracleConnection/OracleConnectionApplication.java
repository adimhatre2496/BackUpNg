package com.example.OracleConnection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OracleConnectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(OracleConnectionApplication.class, args);
	}

}
